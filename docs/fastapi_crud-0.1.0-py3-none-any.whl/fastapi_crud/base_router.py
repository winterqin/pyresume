from fastapi import APIRouter, Depends
from typing import Callable, Type, TypeVar, Generic
from pydantic import BaseModel

TCreate = TypeVar("TCreate", bound=BaseModel)
TUpdate = TypeVar("TUpdate", bound=BaseModel)


class BaseRouter(Generic[TCreate, TUpdate]):
    """通用路由基类，自动生成标准 CRUD 接口"""

    def __init__(
        self,
        get_service: Callable,
        create_schema: Type[TCreate],
        update_schema: Type[TUpdate],
        prefix: str = None,
        tags: list = None,
    ):
        self.get_service = get_service
        self.create_schema = create_schema
        self.update_schema = update_schema
        self.router = APIRouter(prefix=prefix, tags=tags)
        self._register_routes()

    def _register_routes(self):
        CreateSchema = self.create_schema
        UpdateSchema = self.update_schema

        @self.router.get("/all")
        def get_all(
            skip: int = 0,
            limit: int = 100,
            order_by: str = None,
            desc_order: bool = False,
            service=Depends(self.get_service),
        ):
            return service.get_all(skip, limit, order_by, desc_order)

        @self.router.post("/create")
        def create(data: CreateSchema, service=Depends(self.get_service)):
            return service.create(data.dict())

        @self.router.get("/{id}")
        def get(id: int, service=Depends(self.get_service)):
            return service.get(id)

        @self.router.put("/{id}")
        def update(id: int, data: UpdateSchema, service=Depends(self.get_service)):
            return service.update(id, data.dict())

        @self.router.delete("/{id}")
        def delete(id: int, service=Depends(self.get_service)):
            return service.delete(id)
