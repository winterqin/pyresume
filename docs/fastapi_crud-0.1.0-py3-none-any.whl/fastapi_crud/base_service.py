from typing import TypeVar, Generic
from pydantic import BaseModel
from .base_dao import BaseDAO

T = TypeVar('T')


class BaseService(Generic[T]):
    """通用 Service 基类"""

    def __init__(self, dao: BaseDAO[T]):
        self.dao = dao

    def create(self, data: dict):
        return self.dao.create(data)

    def get(self, id: int):
        return self.dao.get(id)

    def update(self, id: int, data: dict):
        data['id'] = id
        return self.dao.update(data)

    def delete(self, id: int):
        return self.dao.delete(id)

    def get_all(
        self, skip: int = 0, limit: int = 100, order_by: str = None, desc_order: bool = False
    ):
        return self.dao.get_all(skip, limit, order_by, desc_order)
