import { HomeIcon, FileText, BuildingIcon } from "lucide-react";
import Index from "./pages/Index.jsx";
import ApplicationList from "./pages/ApplicationList.jsx";
import CompanyList from "./pages/CompanyList.jsx";

/**
 * Central place for defining the navigation items. Used for navigation components and routing.
 */
export const navItems = [
  {
    title: "Home",
    to: "/",
    icon: <HomeIcon className="h-4 w-4" />,
    page: <Index />,
  },
  {
    title: "求职记录",
    to: "/applications",
    icon: <FileText className="h-4 w-4" />,
    page: <ApplicationList />,
  },
  {
    title: "公司管理",
    to: "/companies",
    icon: <BuildingIcon className="h-4 w-4" />,
    page: <CompanyList />,
  },
];
