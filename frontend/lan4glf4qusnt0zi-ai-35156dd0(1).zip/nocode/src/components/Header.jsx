import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, FileText, BuildingIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const navigate = useNavigate();

  return (
    <div className="mb-6 bg-white rounded-lg shadow p-4">
      <div className="flex space-x-4">
        <Button 
          onClick={() => navigate('/')}
          variant="default"
          className="flex items-center"
        >
          <Home className="w-4 h-4 mr-2" />
          首页
        </Button>
        <Button 
          onClick={() => navigate('/applications')}
          variant="secondary"
          className="flex items-center"
        >
          <FileText className="w-4 h-4 mr-2" />
          求职记录
        </Button>
        <Button 
          onClick={() => navigate('/companies')}
          variant="secondary"
          className="flex items-center"
        >
          <BuildingIcon className="w-4 h-4 mr-2" />
          公司管理
        </Button>
      </div>
    </div>
  );
};

export default Header;
