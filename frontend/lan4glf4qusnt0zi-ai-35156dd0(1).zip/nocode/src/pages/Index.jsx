import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { CardContent, CardHeader, Card, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { Building, Calendar, MapPin, BuildingIcon, FileText, Home } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { Bar, Legend, PieChart, Tooltip, BarChart, CartesianGrid, ResponsiveContainer, Pie, Cell, XAxis, YAxis } from 'recharts';
import Header from '@/components/Header';

const Index = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('application')
        .select(`
          id,
          position,
          base,
          salery,
          status,
          resume,
          update_at,
          created_at,
          company (
            company_name
          )
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('获取求职记录失败:', error);
    } finally {
      setLoading(false);
    }
  };

  // 求职状态统计数据
  const statusData = [
    { name: '已投递', value: applications.filter(app => app.status === '已投递').length },
    { name: '已查看', value: applications.filter(app => app.status === '已查看').length },
    { name: '面试中', value: applications.filter(app => app.status === '面试中').length },
    { name: '已拒绝', value: applications.filter(app => app.status === '已拒绝').length },
    { name: '已录用', value: applications.filter(app => app.status === '已录用').length },
  ];

  // 各阶段统计柱状图数据
  const stageData = [
    { name: '简历筛选', 投递数: applications.length, 通过数: applications.filter(app => app.status !== '已拒绝').length },
    { name: '初试', 投递数: applications.filter(app => app.status !== '已投递').length, 通过数: applications.filter(app => app.status === '面试中' || app.status === '已录用').length },
    { name: '复试', 投递数: applications.filter(app => app.status === '面试中' || app.status === '已录用').length, 通过数: applications.filter(app => app.status === '已录用').length },
    { name: '终面', 投递数: applications.filter(app => app.status === '面试中' || app.status === '已录用').length, 通过数: applications.filter(app => app.status === '已录用').length },
    { name: 'Offer', 投递数: applications.filter(app => app.status === '已录用').length, 通过数: applications.filter(app => app.status === '已录用').length },
  ];

  // 饼图颜色配置
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  if (loading) {
    return <div className="flex justify-center items-center h-screen">加载中...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* 导航栏 */}
      <Header />

      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">求职进度管理仪表盘</h1>
          <p className="text-gray-600 mt-2">跟踪您的求职进度和状态</p>
        </div>

        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Building className="text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">总投递数</p>
                  <p className="text-2xl font-bold">{applications.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="bg-yellow-100 p-3 rounded-full mr-4">
                  <Calendar className="text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">本周投递</p>
                  <p className="text-2xl font-bold">
                    {applications.filter(app => {
                      const oneWeekAgo = new Date();
                      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
                      return new Date(app.created_at) > oneWeekAgo;
                    }).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="bg-green-100 p-3 rounded-full mr-4">
                  <Building className="text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">面试中</p>
                  <p className="text-2xl font-bold">{applications.filter(app => app.status === '面试中').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="bg-purple-100 p-3 rounded-full mr-4">
                  <Building className="text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">已录用</p>
                  <p className="text-2xl font-bold">{applications.filter(app => app.status === '已录用').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="bg-red-100 p-3 rounded-full mr-4">
                  <Building className="text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">成功率</p>
                  <p className="text-2xl font-bold">
                    {applications.length > 0 
                      ? ((applications.filter(app => app.status === '已录用').length / applications.length) * 100).toFixed(1) + '%' 
                      : '0%'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 图表区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* 饼图 - 状态分布 */}
          <Card>
            <CardHeader>
              <CardTitle>求职状态分布</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* 柱状图 - 阶段统计 */}
          <Card>
            <CardHeader>
              <CardTitle>各阶段通过情况</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={stageData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="投递数" fill="#8884d8" />
                  <Bar dataKey="通过数" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* 求职记录表格 */}
        <Card>
          <div className="flex flex-col space-y-1.5 p-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-semibold leading-none tracking-tight">最近求职记录</h3>
              <button 
                onClick={() => navigate('/applications')}
                className="text-blue-500 hover:text-blue-700 flex items-center"
              >
                <FileText className="w-4 h-4 mr-1" />
                查看详细记录
              </button>
            </div>
          </div>
          <CardContent>
            <div className="space-y-4">
              {applications.map((record) => (
                <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center">
                    <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16" />
                    <div className="ml-4">
                      <h3 className="font-semibold text-lg">{record.company?.company_name || '未知公司'}</h3>
                      <p className="text-gray-600">{record.position}</p>
                      <div className="flex items-center mt-1 text-sm text-gray-500">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{record.base}</span>
                        <Calendar className="w-4 h-4 ml-3 mr-1" />
                        <span>{new Date(record.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <Badge className={`${
                    record.status === '已投递' ? 'bg-yellow-500' :
                    record.status === '已查看' ? 'bg-green-500' :
                    record.status === '面试中' ? 'bg-blue-500' :
                    record.status === '已拒绝' ? 'bg-red-500' :
                    record.status === '已录用' ? 'bg-purple-500' : 'bg-gray-500'
                  } text-white`}>
                    {record.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;
