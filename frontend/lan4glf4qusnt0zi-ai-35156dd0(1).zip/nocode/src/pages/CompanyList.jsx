import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building, Plus, Edit, Trash2 } from 'lucide-react';
import { supabase } from "@/integrations/supabase/client";
import { toast } from 'sonner';
import Header from '@/components/Header';

const CompanyList = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    id: null,
    company_name: '',
    website_link: '',
    login_type: '',
    uname: '',
    upass: ''
  });

  const ITEMS_PER_PAGE = 10;

  useEffect(() => {
    fetchCompanies();
  }, [currentPage, searchTerm]);

  const fetchCompanies = async () => {
    try {
      setLoading(true);
      const from = (currentPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      let query = supabase
        .from('company')
        .select('*', { count: 'exact' })
        .order('company_name');

      if (searchTerm) {
        query = query.or(`company_name.ilike.%${searchTerm}%,website_link.ilike.%${searchTerm}%`);
      }

      const { data, count, error } = await query.range(from, to);

      if (error) throw error;
      
      setCompanies(data || []);
      setTotalPages(Math.ceil(count / ITEMS_PER_PAGE));
    } catch (error) {
      console.error('获取公司列表失败:', error);
      toast.error('获取公司列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    try {
      const { error } = await supabase
        .from('company')
        .insert([{
          company_name: formData.company_name,
          website_link: formData.website_link,
          login_type: formData.login_type,
          uname: formData.uname,
          upass: formData.upass
        }]);

      if (error) throw error;
      
      toast.success('公司信息创建成功');
      setIsDialogOpen(false);
      resetForm();
      fetchCompanies();
    } catch (error) {
      console.error('创建公司信息失败:', error);
      toast.error('创建公司信息失败');
    }
  };

  const handleUpdate = async () => {
    try {
      const { error } = await supabase
        .from('company')
        .update({
          company_name: formData.company_name,
          website_link: formData.website_link,
          login_type: formData.login_type,
          uname: formData.uname,
          upass: formData.upass
        })
        .eq('id', formData.id);

      if (error) throw error;
      
      toast.success('公司信息更新成功');
      setIsDialogOpen(false);
      resetForm();
      fetchCompanies();
    } catch (error) {
      console.error('更新公司信息失败:', error);
      toast.error('更新公司信息失败');
    }
  };

  const handleDelete = async (id) => {
    try {
      const { error } = await supabase
        .from('company')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast.success('公司信息删除成功');
      fetchCompanies();
    } catch (error) {
      console.error('删除公司信息失败:', error);
      toast.error('删除公司信息失败');
    }
  };

  const resetForm = () => {
    setFormData({
      id: null,
      company_name: '',
      website_link: '',
      login_type: '',
      uname: '',
      upass: ''
    });
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (company) => {
    setFormData({
      id: company.id,
      company_name: company.company_name,
      website_link: company.website_link,
      login_type: company.login_type,
      uname: company.uname,
      upass: company.upass
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.id) {
      handleUpdate();
    } else {
      handleCreate();
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen">加载中...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* 导航栏 */}
      <Header />

      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">公司信息管理</h1>
          <p className="text-gray-600 mt-2">管理您的公司信息</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>公司信息列表</CardTitle>
              <div className="flex gap-4">
                <Input
                  placeholder="搜索公司名称或网站..."
                  value={searchTerm}
                  onChange={handleSearch}
                  className="w-64"
                />
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={openCreateDialog}>
                      <Plus className="w-4 h-4 mr-2" />
                      新增公司
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>
                        {formData.id ? '编辑公司信息' : '新增公司信息'}
                      </DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="company_name">公司名称</Label>
                        <Input
                          id="company_name"
                          value={formData.company_name}
                          onChange={(e) => setFormData({...formData, company_name: e.target.value})}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="website_link">网站链接</Label>
                        <Input
                          id="website_link"
                          value={formData.website_link}
                          onChange={(e) => setFormData({...formData, website_link: e.target.value})}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="login_type">登录方式</Label>
                        <Select
                          value={formData.login_type}
                          onValueChange={(value) => setFormData({...formData, login_type: value})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="选择登录方式" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="邮箱">邮箱</SelectItem>
                            <SelectItem value="手机号">手机号</SelectItem>
                            <SelectItem value="用户名">用户名</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="uname">用户名</Label>
                        <Input
                          id="uname"
                          value={formData.uname}
                          onChange={(e) => setFormData({...formData, uname: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="upass">密码</Label>
                        <Input
                          id="upass"
                          type="password"
                          value={formData.upass}
                          onChange={(e) => setFormData({...formData, upass: e.target.value})}
                        />
                      </div>
                      
                      <div className="flex justify-end gap-2">
                        <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                          取消
                        </Button>
                        <Button type="submit">
                          {formData.id ? '更新' : '创建'}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>公司名称</TableHead>
                  <TableHead>网站链接</TableHead>
                  <TableHead>登录方式</TableHead>
                  <TableHead>用户名</TableHead>
                  <TableHead>创建时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {companies.map((company) => (
                  <TableRow key={company.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <Building className="w-5 h-5 mr-2 text-gray-500" />
                        {company.company_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      <a 
                        href={company.website_link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        {company.website_link}
                      </a>
                    </TableCell>
                    <TableCell>{company.login_type || '未设置'}</TableCell>
                    <TableCell>{company.uname || '未设置'}</TableCell>
                    <TableCell>
                      {new Date(company.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditDialog(company)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(company.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {/* 分页控件 */}
            <div className="flex justify-between items-center mt-6">
              <div className="text-sm text-gray-500">
                共 {totalPages * ITEMS_PER_PAGE} 条记录
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  上一页
                </Button>
                <span className="flex items-center px-3 text-sm">
                  第 {currentPage} 页，共 {totalPages} 页
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  下一页
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CompanyList;
